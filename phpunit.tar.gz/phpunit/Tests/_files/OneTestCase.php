<?php
class OneTestCase extends PHPUnit_Framework_TestCase
{
    public function noTestCase()
    {
    }

    public function testCase($arg = '')
    {
    }
}
