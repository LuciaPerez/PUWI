<?php
class ConcreteTest extends AbstractTest
{
    public function testTwo()
    {
    }
}
